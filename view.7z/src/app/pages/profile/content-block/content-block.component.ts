import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'content-block',
  templateUrl: './content-block.component.html',
  styleUrls: ['./content-block.component.scss']
})
export class ContentBlockComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
