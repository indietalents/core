import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'post-wall',
  templateUrl: './post-wall.component.html',
  styleUrls: ['./post-wall.component.scss']
})
export class PostWallComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
