import { Component } from '@angular/core';

@Component ({
    selector: 'msw-navbar',
    templateUrl: './navigation.component.html'
})

export class NavigationComponent {}
