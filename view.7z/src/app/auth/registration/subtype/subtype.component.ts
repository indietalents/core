import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'subtype',
  templateUrl: './subtype.component.html',
  styleUrls: ['./subtype.component.scss']
})
export class SubtypeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    console.log('Subtype component loaded!');
  }

}
