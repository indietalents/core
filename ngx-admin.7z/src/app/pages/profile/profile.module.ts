import { ThemeModule } from './../../@theme/theme.module';
import { HeaderBlockModule } from './header-block/header-block.module';
import { PostWallComponent } from './post-wall/post-wall.component';
import { HeaderBlockComponent } from './header-block/header-block.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProfileComponent } from './profile.component';

@NgModule({
  imports: [
    CommonModule, HeaderBlockModule, ThemeModule
  ],
  declarations: [ProfileComponent, PostWallComponent]
})
export class ProfileModule { }