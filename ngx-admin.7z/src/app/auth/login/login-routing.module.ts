import { NgModule }             from '@angular/core';
import { Routes, RouterModule } from '@angular/router';



export const appRoutes: Routes = [
    // 1st Route
    { path: 'type',  component: Pr },
    // 2nd Route
    { path: 'subtype',  component: WorkComponent, canActivate: [WorkflowGuard] },
    // 3rd Route
    { path: 'info',  component: AddressComponent, canActivate: [WorkflowGuard] },
    // 4th Route
    { path: 'result',  component: ResultComponent, canActivate: [WorkflowGuard] },
    // 5th Route
    { path: '',   redirectTo: '/profile', pathMatch: 'full' },
    // 6th Route
    { path: '**', component: PersonalComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(appRoutes, { useHash: true} )],
  exports: [RouterModule],
  providers: [WorkflowGuard]
})
export class LoginRoutingModule {}