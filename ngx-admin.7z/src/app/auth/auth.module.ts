import { MainInfoComponent } from './registration/main-info/main-info.component';
import { SubtypeComponent } from './registration/subtype/subtype.component';
import { TypeComponent } from './registration/type/type.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AuthComponent } from './auth.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [
    AuthComponent,
    TypeComponent,
    SubtypeComponent,
    MainInfoComponent
]
})
export class AuthModule { }