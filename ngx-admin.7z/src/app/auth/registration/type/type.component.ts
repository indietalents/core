import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'undefined-type',
  templateUrl: './type.component.html',
  styleUrls: ['./type.component.scss']
})
export class TypeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
