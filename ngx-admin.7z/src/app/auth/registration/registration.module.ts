import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RegistrationComponent } from './registration.component';
import { WorkflowComponent } from './workflow/workflow.component';
import { WorkflowGuardComponent } from './workflow-guard/workflow-guard.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [RegistrationComponent,
    WorkflowComponent,
    WorkflowGuardComponent
]
})
export class RegistrationModule { }