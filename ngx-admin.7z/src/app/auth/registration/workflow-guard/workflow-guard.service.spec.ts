/* tslint:disable:no-unused-variable */

import { TestBed, async, inject } from '@angular/core/testing';
import { WorkflowGuardService } from './workflow-guard.service';

describe('Service: WorkflowGuard', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [WorkflowGuardService]
    });
  });

  it('should ...', inject([WorkflowGuardService], (service: WorkflowGuardService) => {
    expect(service).toBeTruthy();
  }));
});