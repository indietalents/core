import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'undefined-workflow-guard',
  templateUrl: './workflow-guard.component.html',
  styleUrls: ['./workflow-guard.component.scss']
})
export class WorkflowGuardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
