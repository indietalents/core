import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'undefined-subtype',
  templateUrl: './subtype.component.html',
  styleUrls: ['./subtype.component.scss']
})
export class SubtypeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
