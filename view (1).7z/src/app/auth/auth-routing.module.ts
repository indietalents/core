import { AuthComponent } from './auth.component';
import { RegistrationComponent } from './registration/registration.component';
import { NgModule }             from '@angular/core';
import { Routes, RouterModule } from '@angular/router';


export const appRoutes: Routes = [
  {
    path: '',
    component: AuthComponent,
    children: [
      {
        path: 'register',
        component: RegistrationComponent,
      },
      {
        path: 'login',
        component: RegistrationComponent,
      },
      {
        path: 'register',
        component: RegistrationComponent,
      },
      { path: '', redirectTo: 'register', pathMatch: 'full' },
      { path: '**', redirectTo: 'register' },
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(appRoutes)],
  exports: [RouterModule],
 // providers: [WorkflowGuard]
})
export class AuthRoutingModule {}