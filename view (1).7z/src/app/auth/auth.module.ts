import { RegistrationRoutingModule } from './registration/registration-routing.module';
import { FormsModule } from './../pages/forms/forms.module';
import { NavigationComponent } from './registration/navigation/navigation.component';
import { RouterModule } from '@angular/router';
import { RegistrationModule } from './registration/registration.module';
import { RegistrationComponent } from './registration/registration.component';
import { MainInfoComponent } from './registration/main-info/main-info.component';
import { SubtypeComponent } from './registration/subtype/subtype.component';
import { TypeComponent } from './registration/type/type.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AuthComponent } from './auth.component';

@NgModule({
  imports: [
    CommonModule, RegistrationModule, RouterModule, FormsModule, RegistrationRoutingModule
  ],
  declarations: [
    AuthComponent,
    NavigationComponent
]
})
export class AuthModule { }