export class FormData {
    type: string = '';
    subtype: string = '';
    
    name: string = '';
    email: string = '';


    clear() {
        this.type = '';
        this.subtype = '';
        this.name = '';
        this.email = '';
    }
}

export class Type {

    musician: 'musician';

}

export class Subtype {

    musician: 'musician';

}

export class MainInfo {

    name: string = '';
    email: string = '';

}