export const STEPS = {
    type: 'type',
    subtype: 'subtype',
    info: 'info'
}