import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'undefined-main-info',
  templateUrl: './main-info.component.html',
  styleUrls: ['./main-info.component.scss']
})
export class MainInfoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
