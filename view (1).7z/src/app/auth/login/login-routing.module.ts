import { NgModule }             from '@angular/core';
import { Routes, RouterModule } from '@angular/router';


@NgModule({
})
export class LoginRoutingModule {}