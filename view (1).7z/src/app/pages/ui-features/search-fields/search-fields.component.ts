import { Component } from '@angular/core';

@Component({
    selector: 'ngx-search-fields',
    templateUrl: 'search-fields.component.html',
})
export class SearchComponent {
}
