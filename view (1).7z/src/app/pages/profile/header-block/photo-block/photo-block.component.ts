import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'photo-block',
  templateUrl: './photo-block.component.html',
  styleUrls: ['./photo-block.component.scss']
})
export class PhotoBlockComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
